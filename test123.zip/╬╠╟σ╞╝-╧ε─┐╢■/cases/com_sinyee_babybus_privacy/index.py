from public.base.base_case import base_case


class case_bb(base_case):
    def __init__(self):
        super(case_bb, self).__init__()

    def main(self):

        # 选择页面
        from scripts.airtest_cocos.pages.com_sinyee_babybus_privacy.Select import Select
        case_obj = Select().run_all()

        # 女孩互动页面
        from scripts.airtest_cocos.pages.com_sinyee_babybus_privacy.Girl import Girl
        case_obj = Girl().run_all()

        print("page complete")