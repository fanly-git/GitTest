from public.base.base_page import base_page
from public.tools import case_report


class Girl(base_page):
    def __init__(self):
        super(Girl, self).__init__()

    @case_report(desc="游戏选择页面-场景3-女孩页面-水枪")
    def case_num_0_girl(self):
        poco = self.act.poco
        self.act.time.sleep(5)
        '''进入女孩互动场景'''
        poco("auto_select/nokissandhold/1").exists()
        poco("auto_select/nokissandhold/1").click()
        self.act.time.sleep(20)
        '''装水枪场景'''
        poco("auto_nokissandhold/gun/bottle/2").drag_to(poco("auto_nokissandhold/gun/water/1"))
        poco("auto_nokissandhold/gun/watertap/1").double_click(self, focus=None, sleep_interval=1)
        self.act.time.sleep(10)
        poco("auto_nokissandhold/arrow").swipe([0, 0.5], focus=None, duration=0.5)
        poco("auto_nokissandhold/arrow").swipe([0, 1], focus=None, duration=0.5)
        self.act.time.sleep(30)

    @case_report(desc="装喇叭场景")
    def case_num_1_girl(self):
        poco = self.act.poco
        self.act.time.sleep(3)
        '''装喇叭场景'''
        poco("auto_nokissandhold/horn/3_1").drag_to(poco("auto_nokissandhold/horn/3"))
        poco("auto_nokissandhold/horn/4_1").drag_to(poco("auto_nokissandhold/horn/4"))
        poco("auto_nokissandhold/horn/2_1").drag_to(poco("auto_nokissandhold/horn/2"))
        poco("auto_nokissandhold/horn/1_1").drag_to(poco("auto_nokissandhold/horn/1"))
        self.act.time.sleep(30)

    @case_report(desc="滑板车打气场景")
    def case_num_2_girl(self):
        poco = self.act.poco
        self.act.time.sleep(3)
        '''滑板车打气场景'''
        poco("auto_nokissandhold/gas/4").drag_to(poco("auto_nokissandhold/gas/3"))
        self.act.time.sleep(30)
        '''返回选择场景'''
        poco("auto_g/button/btn_back").click()
        self.act.time.sleep(10)




