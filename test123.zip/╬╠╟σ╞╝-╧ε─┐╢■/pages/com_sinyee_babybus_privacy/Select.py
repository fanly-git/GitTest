from public.base.base_page import base_page
from public.tools import case_report


class Select(base_page):
    def __init__(self):
        super(Select, self).__init__()

    @case_report(desc="从欢迎界面进入性别选择场景页面")
    def case_num_0_select(self):
        poco = self.act.poco
        self.act.time.sleep(3)
        '''进入游戏界面'''
        poco("auto_gameplay/play").click()
        self.act.time.sleep(10)
        '''进入男孩互动界面'''
        poco("Boy").click()
        self.act.time.sleep(20)
        '''返回选择场景'''
        poco("auto_g/button/btn_back").click()
        self.act.time.sleep(10)
        poco = self.act.poco
        self.act.time.sleep(3)
        '''进入女孩互动界面'''
        poco("Girl").click()
        self.act.time.sleep(40)

    @case_report(desc="涂色页面")
    def case_num_1_select(self):
        poco = self.act.poco
        self.act.time.sleep(3)
        '''选择颜色'''
        poco("auto_drawing/pen/pen/pannel").click()
        self.act.time.sleep(10)
        '''进行正面涂色'''
        spot = [[0, 0], [0, 0.1], [0, 0.2], [0, 0.3], [0, 0.4], [0, 0.5], [0, 0.6], [0, 0.7], [0, 0.8], [0, 0.9], [0, 1]]
        spot1 = [[1, 0], [1, 0.1], [1, 0.2], [1, 0.3], [1, 0.4], [1, 0.5], [1, 0.6], [1, 0.7], [1, 0.8], [1, 0.9], [1, 1]]
        for i in range(len(spot)):
            for ii in range(len(spot1)):
                begin = poco("auto_drawing/girl/front/big/1").focus(spot[i])
                end = poco("auto_drawing/girl/front/big/1").focus(spot1[ii])
                begin.drag_to(end, duration=0.5)
            if poco("auto_drawing/pen/ok/btn").exists():
                break
        poco("auto_drawing/pen/ok/btn").wait_for_appearance()
        '''正面涂色完成，点击打钩按钮'''
        poco("auto_drawing/pen/ok/btn").click()
        self.act.time.sleep(10)
        '''进行背面涂色'''
        spot2 = [[0, 0], [0, 0.1], [0, 0.2], [0, 0.3], [0, 0.4], [0, 0.5], [0, 0.6], [0, 0.7], [0, 0.8], [0, 0.9],
                [0, 1]]
        spot3 = [[1, 0], [1, 0.1], [1, 0.2], [1, 0.3], [1, 0.4], [1, 0.5], [1, 0.6], [1, 0.7], [1, 0.8], [1, 0.9],
                 [1, 1]]
        for j in range(len(spot2)):
            for jj in range(len(spot3)):
                begin = poco("auto_drawing/girl/back/big/1").focus(spot2[j])
                end = poco("auto_drawing/girl/back/big/1").focus(spot3[jj])
                begin.drag_to(end, duration=0.5)
            if poco("auto_drawing/pen/ok/btn").exists():
                break
        poco("auto_drawing/pen/ok/btn").wait_for_appearance()
        '''背面涂色完成，点击打钩按钮'''
        poco("auto_drawing/pen/ok/btn").click()
        self.act.time.sleep(10)

    @case_report(desc="找不能看、不能摸的地方")
    def case_num_2_select(self):
        poco = self.act.poco
        self.act.time.sleep(3)
        '''找到第一个不能看、不能摸的地方'''
        poco("auto_chooserole/circle/1").click()
        self.act.time.sleep(3)
        '''找到第二个不能看、不能摸的地方'''
        poco("auto_chooserole/circle/1_sub_index_0").click()
        self.act.time.sleep(10)
        '''找到第三个不能看、不能摸的地方'''
        poco("auto_chooserole/circle/1").click()
        self.act.time.sleep(40)